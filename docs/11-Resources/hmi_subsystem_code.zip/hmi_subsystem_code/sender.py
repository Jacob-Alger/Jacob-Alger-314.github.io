# sender.py
# Jacob Alger - Team 202 - EGR 314
#
# Outgoing packet assembly and transmission.
# All button-to-message mapping lives in main.py — this module only
# exposes send_packet(), which any part of the codebase can call.

import time
from protocol import build_packet, ID_HMI   # packet assembler and our own ID
from hardware import uart, led_blue, BLUE_BRIGHTNESS

# ===========================================================================
# PACKET SENDER
# ===========================================================================

def send_packet(dest_id, message_str, label="", suppress_blue_pulse=False):
    """
    Build, validate, and transmit one complete packet over UART.

    Arguments:
        dest_id     — integer byte ID of the destination subsystem
                      (use the ID_xxx constants from protocol.py)
        message_str — the message body as a plain Python string,
                      e.g. "WD:S:F;" or "AR:S:Read;"
        label       — optional short description for console output
                      and OLED display feedback (e.g. "Drive Forward")

    Returns:
        The label string if the packet was sent successfully.
        None if build_packet() rejected the message (too long, bad bytes, etc.)
    """

    # Ask protocol.py to assemble the full packet bytes.
    # build_packet() handles all validation (length, forbidden bytes, etc.)
    # and returns None with an error print if anything is wrong.
    # ID_HMI is always our source ID — we are always the sender here.
    packet = build_packet(ID_HMI, dest_id, message_str)

    if packet is None:
        return None   # build_packet already printed the reason; nothing to send

    # Append carriage return + newline (\r\n) so the receiving board's
    # line-buffer knows the packet is complete.
    # The '\n' is what receiver.py's buffer watches for as an end-of-packet marker.
    raw = packet + b'\r\n'

    # Pulse the blue LED to give a visible sign that bytes are going out.
    if not suppress_blue_pulse:
        led_blue.duty_u16(BLUE_BRIGHTNESS)
    uart.write(raw)
    if not suppress_blue_pulse:
        led_blue.duty_u16(0)

    # Print a transmission summary to the console (visible in mpremote / Thonny).
    print(f"\n--- Sent ({len(packet)} bytes) ---")
    print(f"  To     : '{chr(dest_id)}' (0x{dest_id:02X})")   # show char and hex
    print(f"  Message: {message_str}")
    if label:
        print(f"  Type   : {label}")

    # Return the label so main.py can display it on the OLED as feedback.
    # If no label was provided, return the raw message string instead.
    return label if label else message_str
