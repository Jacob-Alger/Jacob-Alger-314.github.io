# main.py
# Jacob Alger - Team 202 - EGR 314
# HMI ESP32-S3 — unified main loop.
# Code generated with assistance from Claude.
#
# ── MODES (cycled by MENU button) ────────────────────────────────────────────
#   0 — Sensor Menu   : scroll list of sensors, open submenus for readings
#   1 — Wheel Drive   : hold UP/DOWN/LEFT/RIGHT to drive, sends every DRIVE_INTERVAL_MS
#   2 — Arm Drive     : hold buttons to control arm position
#   3 — Button Test   : shows button name while held, clears on release
#
# ── FULL API COVERAGE (sent messages) ────────────────────────────────────────
#   ST:S:Start;        Start broadcast          → X  (all, start screen SEL)
#   WD:S:F/B/L/R;      Wheel drive direction    → w  (wheel drive mode)
#   AD:S:U/D/L/R;      Arm drive direction      → a  (arm drive mode)
#   AR:S:Read;         Accel read request       → p  (sensor menu)
#   TR:S:Read;         Temperature read request → t  (sensor menu)
#   HR:S:Read;         Humidity read request    → t  (sensor menu)
#   MR:S:Read;         Metal detector request   → m  (sensor menu)
#   CU:S:C/F;          Change temp unit         → t  (temp submenu RIGHT btn)
#
# ── DRIVE RATE ───────────────────────────────────────────────────────────────
DRIVE_INTERVAL_MS = 500    # Change DRIVE_INTERVAL_MS to control how fast held-button drive commands fire.
# ─────────────────────────────────────────────────────────────────────────────
# ── START TIMEOUT ─────────────────────────────────────────────────────────────
START_TIMEOUT_MS = 15000   # milliseconds to wait for broadcast echo
# ─────────────────────────────────────────────────────────────────────────────

import time
import my_oled
import hardware

from hardware import (uart, buttons, pressed_lock, BUTTON_PINS, BUTTON_NAMES, led_blue, wifi_ready, BLUE_BRIGHTNESS)
from receiver import process_incoming, last_readings
from sender import send_packet
from protocol import (ID_WHEEL, ID_ACCEL, ID_ARM, ID_TEMP, ID_METAL, ID_BCAST)

# ===========================================================================
# STARTUP STATE MACHINE
# Controls the boot sequence before the main app starts.
# Using descriptive string constants makes the code easier to read than
# using integers (0, 1, 2...) for states.
# ===========================================================================

STARTUP_MQTT    = 'mqtt'      # waiting for wifi_ready signal from comm subsystem
STARTUP_IDLE    = 'idle'      # wifi ready — showing start screen, waiting for SEL
STARTUP_WAITING = 'waiting'   # broadcast sent, waiting for echo back
STARTUP_FAILED  = 'failed'    # timeout with no echo — show error
STARTUP_DONE    = 'done'      # echo received (or dev bypass) — app is live

startup_state  = STARTUP_MQTT  # begin by waiting for MQTT connection on boot
start_sent_at  = 0             # will hold ticks_ms() when broadcast was sent
_last_blink_ms = 0             # tracks last blue LED blink toggle while waiting for MQTT
BLINK_MS       = 500           # blue LED blink interval while waiting for MQTT (ms)

# ===========================================================================
# MODE CONSTANTS
# Only meaningful once startup_state == STARTUP_DONE.
# ===========================================================================

MODE_SENSOR_MENU = 0   # scrollable sensor list with submenus
MODE_WHEEL_DRIVE = 1   # hold buttons to send wheel drive commands
MODE_ARM_DRIVE   = 2   # hold buttons to send arm drive commands
MODE_BUTTON_TEST = 3   # shows which button is pressed on the OLED

NUM_MODES = 4          # total number of modes (MENU cycles 0 -> 1 -> 2 -> 3 -> 0)

# Human-readable mode names for console output when MENU is pressed.
MODE_NAMES = {
    MODE_SENSOR_MENU : "SENSORS",
    MODE_WHEEL_DRIVE : "WHEELS",
    MODE_ARM_DRIVE   : "ARM",
    MODE_BUTTON_TEST : "BTN TEST",
}

# ===========================================================================
# SENSOR MENU DEFINITION
# Each entry is a dict describing one sensor and what message to send for it.
# This list drives both the OLED sensor list screen and the submenu behavior.
#
# Keys:
#   label       — display name shown on the sensor list (max 14 chars visible)
#   read_dest   — protocol ID of the subsystem to ask for a reading
#   read_msg    — the message string to send when SELECT is pressed in the submenu
#   read_label  — short label for console output and OLED TX feedback
#   reading_key — key to look up in last_readings when displaying the value
#   unit_toggle — True if this sensor has a unit-change button (RIGHT in submenu)
# ===========================================================================

SENSORS = [
    {
        'label'      : 'Accelerometer',   # shown on list and submenu header
        'read_dest'  : ID_ACCEL,          # send to 'p' (Tyler)
        'read_msg'   : 'AR:S:Read;',      # full message body e.g. AZhpAR:S:Read;YB
        'read_label' : 'Accel Read',      # console label
        'reading_key': 'accel',           # key in last_readings dict
        'unit_toggle': False,             # no unit change for accelerometer
    },
    {
        'label'      : 'Temperature',
        'read_dest'  : ID_TEMP,           # send to 't' (Isaiah)
        'read_msg'   : 'TR:S:Read;',      # AZhtTR:S:Read;YB
        'read_label' : 'Temp Read',
        'reading_key': 'temp',            # stores the float value
        'unit_toggle': True,              # RIGHT button sends CU:S:C/F; to toggle unit
    },
    {
        'label'      : 'Humidity',
        'read_dest'  : ID_TEMP,           # same subsystem as temperature (Isaiah)
        'read_msg'   : 'HR:S:Read;',      # AZhtHR:S:Read;YB
        'read_label' : 'Humid Read',
        'reading_key': 'humid',
        'unit_toggle': False,
    },
    {
        'label'      : 'Metal Detector',
        'read_dest'  : ID_METAL,          # send to 'm' (Aaron)
        'read_msg'   : 'MR:S:Read;',      # AZhmMR:S:Read;YB
        'read_label' : 'Metal Read',
        'reading_key': 'metal',
        'unit_toggle': False,
    },
]

# ===========================================================================
# DRIVE MAPS
# Maps button pin numbers to the packet destination, message, and display label.
# Used by process_drive() and the first-press handler in the button event section.
# pin -> (dest_id, message_str, display_label)
# ===========================================================================

WHEEL_MAP = {
    4 : (ID_WHEEL, "WD:S:F;", "Forward"),   # UP    -> AZhwWD:S:F;YB
    6 : (ID_WHEEL, "WD:S:B;", "Back"),      # DOWN  -> AZhwWD:S:B;YB
    7 : (ID_WHEEL, "WD:S:L;", "Left"),      # LEFT  -> AZhwWD:S:L;YB
    5 : (ID_WHEEL, "WD:S:R;", "Right"),     # RIGHT -> AZhwWD:S:R;YB
}

ARM_MAP = {
    4 : (ID_ARM, "AD:S:U;", "Up"),          # UP    -> AZhaAD:S:U;YB
    6 : (ID_ARM, "AD:S:D;", "Down"),        # DOWN  -> AZhaAD:S:D;YB
    7 : (ID_ARM, "AD:S:L;", "Left"),        # LEFT  -> AZhaAD:S:L;YB
    5 : (ID_ARM, "AD:S:R;", "Right"),       # RIGHT -> AZhaAD:S:R;YB
}

# ===========================================================================
# RUNTIME STATE VARIABLES
# These track what the program is currently doing.
# ===========================================================================

mode          = MODE_SENSOR_MENU   # which mode we start in when app launches
active_button = None               # pin number of currently held button (button test only)

sensor_index  = 0       # which sensor row is highlighted on the sensor list
in_submenu    = False   # True when a sensor submenu is open (vs. the list)
sub_status    = ""      # short status message shown in the submenu (e.g. "Requested...")

_last_drive_send = 0    # ticks_ms() timestamp of the last held-button drive command
_wheel_direction = ""   # currently displayed direction label on wheel screen ("" = blank)
_arm_direction   = ""   # currently displayed direction label on arm screen

# ===========================================================================
# MODE ENTRY FUNCTION
# Called whenever we switch to a new mode (or enter a mode on startup).
# Resets all mode-specific state and draws the correct initial screen.
# ===========================================================================

def enter_mode(m):
    """Reset state and draw the entry screen for mode m."""
    global in_submenu, sub_status, _wheel_direction, _arm_direction

    # Reset all mode-specific state to defaults
    in_submenu       = False   # close any open submenu
    sub_status       = ""      # clear status line
    _wheel_direction = ""      # clear drive direction labels
    _arm_direction   = ""

    # Draw the correct entry screen for the new mode
    if m == MODE_SENSOR_MENU:
        my_oled.draw_sensor_list(SENSORS, sensor_index)
    elif m == MODE_WHEEL_DRIVE:
        my_oled.draw_wheel_drive()   # no direction label on entry
    elif m == MODE_ARM_DRIVE:
        # Pass last_readings so any previously received telemetry is shown immediately
        # when entering the mode, even before the first command is sent.
        my_oled.draw_arm_drive("", last_readings)
    elif m == MODE_BUTTON_TEST:
        my_oled.draw_button_test()   # blank center on entry

# ===========================================================================
# SENSOR SUBMENU FUNCTIONS
# ===========================================================================

def open_submenu(idx):
    """
    Open the submenu for the sensor at index idx.
    Clears the last reading so the user always gets fresh data.
    """
    global in_submenu, sub_status
    in_submenu = True    # flag that we are now inside a submenu
    sub_status = ""      # no status message yet

    # Clear the stored reading so the screen shows "No data yet"
    # rather than stale data from a previous visit.
    last_readings[SENSORS[idx]['reading_key']] = None

    # Also clear the unit for temperature sensors
    if SENSORS[idx]['unit_toggle']:
        last_readings['temp_unit'] = None

    # Draw the submenu (will show "No data yet" until SELECT is pressed)
    my_oled.draw_sensor_sub(SENSORS[idx], last_readings)

def close_submenu():
    """
    Close the current submenu and return to the sensor list.
    """
    global in_submenu, sub_status
    in_submenu = False   # we are back at the list
    sub_status = ""
    my_oled.draw_sensor_list(SENSORS, sensor_index)

def submenu_handle_button(p, idx):
    """
    Handle a button press while inside a sensor submenu.
    p   — pin number of the button that was pressed
    idx — index of the currently open sensor in the SENSORS list
    """
    global sub_status
    sensor = SENSORS[idx]   # shortcut to the current sensor's dict

    if p == 15:   # SELECT — request a fresh reading from the sensor
        # Build and send the read request packet for this sensor
        send_packet(sensor['read_dest'], sensor['read_msg'], sensor['read_label'])
        sub_status = "Requested..."                                   # show pending status
        my_oled.draw_sensor_sub(sensor, last_readings, sub_status)   # refresh display

    elif p == 5 and sensor['unit_toggle']:   # RIGHT — toggle temperature unit
        # Read what unit the sensor last reported
        current  = last_readings.get('temp_unit')

        # Toggle: if current is 'C' send 'F', otherwise send 'C'
        # If current is None (no data yet), default to requesting 'C'
        new_unit = 'C' if current != 'C' else 'F'

        # Send the unit change request: e.g. AZhtCU:S:F;YB
        send_packet(ID_TEMP, f"CU:S:{new_unit};", f"Unit->{new_unit}")

        # Display a status message confirming what was sent
        from_unit = current if current else '?'      # show '?' if unit was unknown
        sub_status = f"{from_unit}->{new_unit} sent"
        my_oled.draw_sensor_sub(sensor, last_readings, sub_status)

    elif p == 16:   # BACK — close submenu, return to sensor list
        close_submenu()   # clears reading, redraws list

# ===========================================================================
# DRIVE MODE HELPER
# Handles continuous sending while a drive button is held.
# Called every main loop iteration when in a drive mode.
# ===========================================================================

def process_drive(drive_map, draw_fn, direction_getter, direction_setter):
    """
    Check for held drive buttons and send commands at DRIVE_INTERVAL_MS rate.
    Also handles clearing the direction label when no button is held.

    drive_map        — WHEEL_MAP or ARM_MAP (dict of pin -> packet info)
    draw_fn          — my_oled.draw_wheel_drive or my_oled.draw_arm_drive
    direction_getter — function that returns the current direction string variable
    direction_setter — function that updates the current direction string variable
    """
    global _last_drive_send

    now = time.ticks_ms()   # current time

    # Check if ANY drive button in this map is currently held (value == 0 = pressed)
    any_held = any(buttons[pin].value() == 0 for pin in drive_map)

    if not any_held:
        # No button held — if we were showing a direction label, clear it
        if direction_getter():            # only redraw if there's something to clear
            direction_setter("")          # clear the stored direction
            draw_fn("")                   # redraw screen with no direction label
        return   # nothing more to do this iteration

    # At least one button is held — check if enough time has passed since last send
    # ticks_diff handles the ms counter wrapping around at its maximum safely
    if time.ticks_diff(now, _last_drive_send) < DRIVE_INTERVAL_MS:
        return   # not time yet — wait for the interval to elapse

    # Find the first held button in the map and send its command
    for pin, (dest, msg, label) in drive_map.items():
        if buttons[pin].value() == 0:    # this specific button is held
            send_packet(dest, msg, label)   # transmit the drive command
            direction_setter(label)          # remember which direction we're showing
            draw_fn(label)                   # update OLED with direction label
            _last_drive_send = now           # record when we last sent
            return   # only send one command per interval (first found wins)

# Getter/setter pairs for the direction label variables.
# process_drive() uses these instead of accessing the globals directly,
# which makes the function reusable for both wheel and arm modes.
def _get_wheel(): return _wheel_direction
def _set_wheel(v):
    global _wheel_direction
    _wheel_direction = v

def _get_arm(): return _arm_direction
def _set_arm(v):
    global _arm_direction
    _arm_direction = v

# ===========================================================================
# DEV BYPASS
# Lets the developer skip the broadcast startup check during testing.
# Activated by holding SEL (pin 15) + BACK (pin 16) + MENU (pin 8)
# simultaneously. Checked both on button press and during the waiting state.
# ===========================================================================

def dev_bypass_held():
    """Returns True if all three bypass buttons are simultaneously held."""
    return (buttons[15].value() == 0 and   # SEL held
            buttons[16].value() == 0 and   # BACK held
            buttons[8].value()  == 0)      # MENU held

# ===========================================================================
# START ECHO DETECTION
# When we send the broadcast ST:S:Start;, every teammate who receives it
# re-sends it with their own ID as source and X (broadcast) as dest.
# e.g. AZtXST:S:Start;YB  (Isaiah re-sent it)
# receiver.py routes broadcast packets and returns a string starting with "BC:".
# We detect the echo by checking for both "BC" and "ST" in that return value.
# ===========================================================================

def is_start_echo(rx_result):
    """
    Returns True if rx_result looks like a broadcast start echo.
    rx_result is the string returned by process_incoming() — it starts with
    "BC: " for broadcast messages, then contains the message body.
    """
    return (rx_result is not None and       # something was received
            'BC' in rx_result and           # it was a broadcast (not direct-to-us)
            'ST' in rx_result)              # it contained the start message name

# ===========================================================================
# STARTUP BANNER (console only)
# ===========================================================================

print("=" * 40)
print("  CropSCOUT HMI  —  ESP32-S3 ready")
print(f"  Drive interval : {DRIVE_INTERVAL_MS} ms")
print(f"  Start timeout  : {START_TIMEOUT_MS // 1000} s")
print("  Dev bypass     : hold SEL + BACK + MENU")
print("=" * 40)

# Start screen is NOT shown yet — we show a blank/waiting state until
# wifi_ready goes high. The STARTUP_MQTT handler draws it when ready.
# Show a simple boot message while MQTT connects.
my_oled.draw_connecting_screen()   # show until wifi_ready goes high

# ===========================================================================
# MAIN LOOP
# Runs forever. Each iteration:
#   1. Check UART for incoming packets (highest priority)
#   2. Handle startup state machine (waiting for echo / timeout)
#   3. Update incoming reading display if in sensor submenu
#   4. Detect button releases (unlock debounce, clear button test label)
#   5. Run drive mode continuous send if applicable
#   6. Handle button press events (IRQ flag from hardware.py)
# ===========================================================================

while True:

    now = time.ticks_ms()   # snapshot the current time once per loop iteration

    # ── 1. UART RX ───────────────────────────────────────────────────────────
    # Always check for incoming bytes first, regardless of what screen we're on.
    # process_incoming() drains the UART buffer, parses complete packets,
    # routes them, and returns a short display string if something useful arrived.
    rx_result = process_incoming(uart)

    # ── 2. STARTUP STATE MACHINE ─────────────────────────────────────────────
    if startup_state == STARTUP_MQTT:
        # Waiting for the comm subsystem to signal that MQTT handshake is complete.
        # wifi_ready is HIGH (1) once the comm and wheel boards have connected.
        # Blue LED blinks slowly to show the system is alive but not yet connected.
        if wifi_ready.value() == 1:
            # MQTT connection established — move to start screen and hold LED solid.
            print("  [STARTUP] WiFi/MQTT ready — showing start screen.")
            led_blue.duty_u16(BLUE_BRIGHTNESS)           # solid blue = ready for user to press SEL
            startup_state = STARTUP_IDLE
            my_oled.draw_start_screen()
        elif dev_bypass_held():
            # Dev bypass on connecting screen — skip MQTT wait and full startup
            print("  [DEV] Bypass on connecting screen — entering app.")
            startup_state = STARTUP_DONE
            led_blue.duty_u16(0)
            enter_mode(mode)
        else:
            # Still waiting — blink the blue LED every BLINK_MS milliseconds.
            # ticks_diff handles the ms counter wrapping safely.
            if time.ticks_diff(now, _last_blink_ms) >= BLINK_MS:
                # Toggle between dim and off for the blink effect
                led_blue.duty_u16(0 if led_blue.duty_u16() else BLUE_BRIGHTNESS)
                _last_blink_ms = now

    elif startup_state == STARTUP_WAITING:
        # We sent the broadcast — check if a teammate echoed it back

        if is_start_echo(rx_result):
            # Echo received — network is alive, enter the main app
            print("  [STARTUP] Echo received — system online.")
            startup_state = STARTUP_DONE
            led_blue.duty_u16(0)              # echo received — turn off waiting LED
            enter_mode(mode)   # draw the first app screen

        elif time.ticks_diff(now, start_sent_at) > START_TIMEOUT_MS:
            # 15 seconds passed with no echo — show failure screen
            print("  [STARTUP] Timed out waiting for echo.")
            startup_state = STARTUP_FAILED
            led_blue.duty_u16(BLUE_BRIGHTNESS)              # timed out — turn off waiting LED
            my_oled.draw_failed_screen()

        elif dev_bypass_held():
            # Dev bypass activated while waiting — skip into app immediately
            print("  [DEV] Bypass during wait — entering app.")
            startup_state = STARTUP_DONE
            led_blue.duty_u16(0)              # echo received — turn off waiting LED
            enter_mode(mode)

    elif startup_state == STARTUP_DONE:
        # App is running — check if an incoming reading should refresh the display

        if rx_result and mode == MODE_SENSOR_MENU and in_submenu:
            # A packet arrived and we're looking at a sensor submenu right now
            sub_status = "Updated"    # show feedback that new data came in
            my_oled.draw_sensor_sub(SENSORS[sensor_index], last_readings, sub_status)

        elif rx_result and mode == MODE_ARM_DRIVE:
            # AA, AS, and AE arrive together after every arm command.
            # Redraw the arm screen with the fresh telemetry values.
            # _get_arm() returns the current direction label (or "" if nothing held).
            my_oled.draw_arm_drive(_get_arm(), last_readings)

    # ── 3. BUTTON RELEASE ────────────────────────────────────────────────────
    # Check every button to see if it has been physically released.
    # On release: unlock its pressed_lock so the IRQ can fire again next press.
    for p in BUTTON_PINS:
        if buttons[p].value() == 1:   # HIGH = released (active LOW buttons)
            pressed_lock[p] = False   # unlock this button for the next press

            # In button test mode, clear the OLED label when the button is released
            if startup_state == STARTUP_DONE and mode == MODE_BUTTON_TEST:
                if p == active_button and p != 8:   # don't clear for MENU (mode switch)
                    active_button = None
                    my_oled.draw_button_test()   # redraw with no label

    # ── 4. DRIVE MODE CONTINUOUS SEND ────────────────────────────────────────
    # If we're in a drive mode, check for held buttons and send at the set rate.
    # This runs every loop iteration — process_drive() internally checks the timer.
    if startup_state == STARTUP_DONE:
        if mode == MODE_WHEEL_DRIVE:
            process_drive(WHEEL_MAP, my_oled.draw_wheel_drive, _get_wheel, _set_wheel)
        elif mode == MODE_ARM_DRIVE:
            # Lambda wrapper: process_drive calls draw_fn(label) with one argument,
            # but draw_arm_drive now also needs last_readings. The lambda bridges that.
            process_drive(ARM_MAP,
                          lambda d: my_oled.draw_arm_drive(d, last_readings),
                          _get_arm, _set_arm)

    # ── 5. BUTTON PRESS EVENT ────────────────────────────────────────────────
    # hardware.button_flag is set True by the IRQ handler when a button is pressed.
    # We read and immediately clear it here to avoid handling the same press twice.
    if hardware.button_flag:
        hardware.button_flag = False        # clear the flag
        p = hardware.last_button            # read which button was pressed
        print(f"GPIO {p} PRESSED  ({BUTTON_NAMES.get(p, '?')})")

        # ── START SCREEN ─────────────────────────────────────────────────────
        if startup_state == STARTUP_IDLE:

            if dev_bypass_held():
                # All three bypass buttons held — skip straight into app
                print("  [DEV] Bypass — skipping broadcast.")
                startup_state = STARTUP_DONE
                led_blue.duty_u16(0)   # bypass skips start, turn off LED
                enter_mode(mode)

            elif p == 15:   # SEL pressed — send the start broadcast
                send_packet(ID_BCAST, "ST:S:Start;", "Start Broadcast", suppress_blue_pulse=True)
                start_sent_at = now          # record when we sent it (for timeout check)
                startup_state = STARTUP_WAITING
                led_blue.duty_u16(BLUE_BRIGHTNESS)            # blue LED on while waiting for echo
                my_oled.draw_waiting_screen()

        # ── FAILED SCREEN ─────────────────────────────────────────────────────
        elif startup_state == STARTUP_FAILED:

            if dev_bypass_held():
                print("  [DEV] Bypass — skipping broadcast.")
                startup_state = STARTUP_DONE
                led_blue.duty_u16(0)   # bypass skips start, turn off LED
                enter_mode(mode)

            elif p == 15:   # SEL — retry the broadcast
                print("  [STARTUP] Retrying broadcast...")
                send_packet(ID_BCAST, "ST:S:Start;", "Start Broadcast", suppress_blue_pulse=True)
                start_sent_at = now
                startup_state = STARTUP_WAITING
                my_oled.draw_waiting_screen()

        # ── RUNNING ───────────────────────────────────────────────────────────
        elif startup_state == STARTUP_DONE:

            # MENU button always cycles to the next mode, from any screen
            if p == 8:
                mode = (mode + 1) % NUM_MODES   # wrap around after the last mode
                print(f"Mode -> {MODE_NAMES[mode]}")
                active_button = None             # clear any held-button state
                enter_mode(mode)                 # draw new mode's entry screen

            # ── Sensor Menu ──────────────────────────────────────────────────
            elif mode == MODE_SENSOR_MENU:
                if not in_submenu:
                    # On the sensor list — handle scroll and selection
                    if p == 4:    # UP — move selection up (wrap at top)
                        sensor_index = (sensor_index - 1) % len(SENSORS)
                        my_oled.draw_sensor_list(SENSORS, sensor_index)

                    elif p == 6:  # DOWN — move selection down (wrap at bottom)
                        sensor_index = (sensor_index + 1) % len(SENSORS)
                        my_oled.draw_sensor_list(SENSORS, sensor_index)

                    elif p == 15: # SELECT — open this sensor's submenu
                        open_submenu(sensor_index)

                    # BACK at the list level has no action (already at top level)

                else:
                    # Inside a sensor submenu — delegate to the submenu handler
                    submenu_handle_button(p, sensor_index)

            # ── Wheel Drive ──────────────────────────────────────────────────
            # First press fires immediately (good responsiveness).
            # Subsequent sends while held are handled by process_drive() above.
            elif mode == MODE_WHEEL_DRIVE:
                if p in WHEEL_MAP:
                    dest, msg, label = WHEEL_MAP[p]   # look up this button's command
                    send_packet(dest, msg, label)       # send immediately on first press
                    _set_wheel(label)                   # update direction label
                    my_oled.draw_wheel_drive(label)     # show it on screen
                    _last_drive_send = now              # start the repeat interval from now

            # ── Arm Drive ────────────────────────────────────────────────────
            elif mode == MODE_ARM_DRIVE:
                if p in ARM_MAP:
                    dest, msg, label = ARM_MAP[p]
                    send_packet(dest, msg, label)
                    _set_arm(label)
                    # Pass last_readings so telemetry rows are visible immediately
                    # even before the response arrives from the arm subsystem
                    my_oled.draw_arm_drive(label, last_readings)
                    _last_drive_send = now

            # ── Button Test ──────────────────────────────────────────────────
            # Shows the button name while held; cleared by the release handler above.
            elif mode == MODE_BUTTON_TEST:
                active_button = p   # remember which button is being held
                my_oled.draw_button_test(BUTTON_NAMES.get(p, f"GPIO{p}"))

    # Small sleep to yield CPU and reduce power consumption.
    # At 10ms per iteration and 9600 baud (~960 bytes/sec), we can comfortably
    # process incoming data without dropping bytes.
    time.sleep_ms(10)