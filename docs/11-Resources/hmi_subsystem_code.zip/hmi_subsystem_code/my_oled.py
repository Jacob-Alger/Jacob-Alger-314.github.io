# my_oled.py
# Jacob Alger - Team 202 - EGR 314
#
# All OLED drawing functions for the CropSCOUT HMI.
#
# ── DISPLAY SPECS ────────────────────────────────────────────────────────────
#   Resolution  : 128 x 64 pixels
#   Driver chip : SSD1306
#   Font        : Built-in 8x8 pixel font
#   Characters  : Max 16 per row  (128 / 8 = 16)
#   Rows        : 8 rows total
#   Row offsets : y = 0, 8, 16, 24, 32, 40, 48, 56
# ─────────────────────────────────────────────────────────────────────────────
#
# ── PATTERN USED BY ALL DRAW FUNCTIONS ───────────────────────────────────────
#   1. oled.fill(0)        — clear the screen to all black (0 = off)
#   2. oled.text(...)      — write text at pixel coordinates (x, y)
#   3. oled.hline(...)     — draw a horizontal line (used as a divider)
#   4. oled.show()         — push the frame buffer to the physical display
#      (nothing appears until .show() is called)
# ─────────────────────────────────────────────────────────────────────────────

from machine import Pin, SoftI2C   # hardware communication classes
import ssd1306                     # OLED driver — talks to the display over I2C
import gfx                         # Graphics helper for shapes (triangles etc.)

# Set up the I2C bus and display object.
# These are the same objects that hardware.py also creates — MicroPython
# caches modules, so this file and hardware.py share the same i2c bus.
i2c      = SoftI2C(scl=Pin(13), sda=Pin(14))   # clock=GPIO13, data=GPIO14
oled     = ssd1306.SSD1306_I2C(128, 64, i2c)   # 128x64 display on that bus
graphics = gfx.GFX(128, 64, oled.pixel)        # shape helper using oled's pixel method

# ===========================================================================
# INTERNAL HELPER
# ===========================================================================

def _header(title):
    """
    Draw a page title on the top row (y=0) and a thin divider line below it.
    Used by every screen to give a consistent look.
    title is truncated to 16 characters to fit the display width.
    """
    oled.text(title[:16], 0, 0)      # draw text at top-left corner
    oled.hline(0, 9, 128, 1)         # horizontal line: x=0, y=9, width=128, color=1(white)

# ===========================================================================
# STARTUP / STATUS SCREENS
# ===========================================================================

def draw_start_screen():
    """
    Initial boot screen shown before the user presses SEL to start.
    Tells the user what to do and hints at the dev bypass combo.
    """
    oled.fill(0)                              # clear display
    oled.text("CropSCOUT Rover",  0,  0)     # title line 1
    oled.text("  Controller",     0, 10)     # title line 2 (indented for centering effect)
    oled.hline(0, 20, 128, 1)                # divider below title
    oled.text("  Press SELECT  ",   0, 30)     # instruction line 1
    oled.text("    to Start    ",      0, 40)     # instruction line 2
    # oled.text("(SEL+BCK+MNU=dev)",0, 54)     # dev bypass hint at bottom
    oled.text(" EGR314-Team202 ",0, 56)         # copyright at bottom
    oled.show()                              # push to display

def draw_connecting_screen():
    """
    Shown on boot while waiting for the comm subsystem to signal
    that the MQTT handshake is complete (wifi_ready pin goes HIGH).
    The blue LED blinks during this time — solid blue means ready.
    """
    oled.fill(0)
    oled.text("CropSCOUT Rover",  0,  0)
    oled.text("  Controller",     0, 10)
    oled.hline(0, 20, 128, 1)
    oled.text("Connecting...",    0, 30)
    oled.text("Wait for solid",   0, 42)
    oled.text("blue LED",         0, 52)
    oled.show()

def draw_waiting_screen():
    """
    Shown after SEL is pressed and the start broadcast has been sent.
    Displayed while we wait up to 15 seconds for a teammate echo.
    """
    oled.fill(0)
    oled.text("CropSCOUT Rover",  0,  0)
    oled.hline(0, 9, 128, 1)
    oled.text("Starting...",      0, 20)
    oled.text("Waiting for",      0, 32)
    oled.text("team response",    0, 42)
    oled.show()

def draw_failed_screen():
    """
    Shown if 15 seconds pass without receiving the broadcast echo back.
    SEL retries, or the dev bypass can still be used to skip the check.
    """
    oled.fill(0)
    oled.text("Start Failed!",    0,  0)
    oled.hline(0, 9, 128, 1)
    oled.text("Timed out after",  0, 20)
    oled.text("15 seconds.",      0, 30)
    oled.text("SEL to retry",     0, 46)
    oled.text("SEL+BCK+MNU=dev",  0, 56)
    oled.show()

# ===========================================================================
# SENSOR SCREENS
# These accept data as parameters so my_oled.py doesn't need to import
# from main.py or receiver.py — keeping this file dependency-free.
# ===========================================================================

def draw_sensor_list(sensors, sensor_index):
    """
    Scrollable sensor selection list.

    sensors      — the SENSORS list from main.py (list of dicts)
    sensor_index — index of the currently highlighted sensor

    Shows up to 5 sensors at a time. If there are more, the list scrolls
    to keep the selected item visible. The selected item is marked with '>'.
    """
    oled.fill(0)
    _header("SENSORS")          # draw "SENSORS" title with divider

    total = len(sensors)        # how many sensors are defined in main.py

    # Calculate which sensor index to start displaying from.
    # This keeps the selected item on screen when scrolling.
    # max(0, ...) prevents going negative.
    # min(sensor_index, total - 5) prevents the list from starting
    # so far down that there aren't enough items to fill the screen.
    start = max(0, min(sensor_index, total - 5))

    # Display up to 5 sensor rows (the screen fits 5 below the header)
    for i, idx in enumerate(range(start, min(start + 5, total))):
        y      = 12 + i * 10   # each row is 10 pixels apart, starting at y=12
        prefix = '>' if idx == sensor_index else ' '   # highlight selected row
        # [:14] truncates the label to leave room for the '>' prefix character
        oled.text(f"{prefix}{sensors[idx]['label'][:14]}", 0, y)

    oled.text("SELECT=open", 0, 56)   # hint at bottom of screen
    oled.show()

def draw_sensor_sub(sensor, last_readings, status_line=""):
    """
    Sensor submenu screen — shown when the user opens a specific sensor.

    sensor        — one dict entry from the SENSORS list in main.py
    last_readings — the last_readings dict from receiver.py
    status_line   — optional short message shown above the bottom hint,
                    e.g. "Requested..." or "Updated" or "F->C sent"

    Layout:
      y=0  : sensor name (header)
      y=9  : divider line
      y=16 : last reading value (or "No data yet" if None)
      y=26 : current unit (temperature only)
      y=36 : "RIGHT=chg unit" hint (temperature only)
      y=46 : status_line (if provided)
      y=56 : "SEL=read BK=list" hint always at bottom
    """
    oled.fill(0)
    _header(sensor['label'][:16])   # sensor name as the page title

    # Look up the last received value for this sensor from the readings dict.
    # sensor['reading_key'] tells us which key to use (e.g. 'accel', 'temp').
    value = last_readings.get(sensor['reading_key'])

    if value is None:
        oled.text("No data yet",           0, 16)   # nothing received yet
    else:
        # [:11] ensures value + "Val: " prefix fits within 16 chars
        oled.text(f"Val: {str(value)[:11]}", 0, 16)

    # Temperature sensor has an extra unit display and toggle hint
    if sensor['unit_toggle']:
        # 'temp_unit' holds "C" or "F", or None if not yet received
        unit = last_readings.get('temp_unit') or '--'
        oled.text(f"Unit: {unit}",         0, 26)
        oled.text("RIGHT=chg unit",        0, 36)

    # Optional status line — shown when something just happened
    if status_line:
        oled.text(status_line[:16],        0, 46)

    oled.text("SEL=read BK=list", 0, 56)   # permanent bottom hint
    oled.show()

# ===========================================================================
# DRIVE SCREENS
# Both wheel and arm drive screens follow the same pattern.
# direction="" clears the active direction label (shown when no button held).
# direction="Forward" etc. shows it while the button is held.
# ===========================================================================

def draw_wheel_drive(direction=""):
    """
    Wheel drive mode screen. Shows button layout and current direction.
    Call with direction="" when no button is held (clears the label).
    Call with direction="Forward" etc. while a button is held.
    """
    oled.fill(0)
    _header("WHEEL DRIVE")
    if direction:
        # Show '>' prefix so it looks like an active indicator
        oled.text(f">{direction[:15]}", 0, 12)
    oled.text("U=Fwd  D=Back",   0, 26)   # top-row button layout hint
    oled.text("L=Left R=Right",  0, 36)   # bottom-row button layout hint
    oled.text("Hold to drive",   0, 56)   # instruction
    oled.show()

def draw_arm_drive(direction="", last_readings=None):
    """
    Arm drive mode screen. Shows live telemetry from the arm subsystem
    alongside the current drive direction.

    direction     — direction label while a button is held ("" = blank)
    last_readings — the last_readings dict from receiver.py, containing:
                      'arm_pos'    : stepper position string, e.g. "200"
                      'arm_status' : one of Idle / Moving / Done / Halted
                      'arm_error'  : error code string "0"–"4"

    Layout (no button guide — wheel drive already shows the control pattern):
      y=0  : "ARM DRIVE" header + divider
      y=12 : ">Direction" while held, blank when released
      y=24 : stepper position  e.g. "Pos: 200"
      y=34 : arm status        e.g. "Stat:Moving"
      y=44 : error             e.g. "Err: OK"  or  "Err: Stall"

    Error code translation (from Caleb's arm subsystem):
      0 = OK            (no error)
      1 = Stall         (motor stalled under load)
      2 = Overcurrent   (driver overcurrent fault)
      3 = Fault         (other DRV8434S fault)
      4 = OutOfRange    (soft position limit reached)
    """
    # Map Caleb's integer error codes to human-readable labels
    ERROR_LABELS = {
        '0': "OK",
        '1': "Stall",
        '2': "Overcurrent",
        '3': "Fault",
        '4': "OutOfRange",
    }

    oled.fill(0)
    _header("ARM DRIVE")   # "ARM DRIVE" at y=0, divider at y=9

    # Direction label — only drawn when a button is held down.
    # process_drive() and the first-press handler both pass "" on release.
    if direction:
        oled.text(f">{direction[:15]}", 0, 12)

    # Pull telemetry values from last_readings, fall back to '--' if not yet received
    if last_readings:
        pos    = last_readings.get('arm_pos')    or '--'
        status = last_readings.get('arm_status') or '--'
        err    = last_readings.get('arm_error')  or '--'
        # Translate the raw error code string to a readable label
        err_label = ERROR_LABELS.get(str(err), str(err))
    else:
        # last_readings not provided — show placeholder dashes
        pos       = '--'
        status    = '--'
        err_label = '--'

    # Draw the three telemetry rows — truncated to fit 16-char display width
    oled.text(f"Pos: {str(pos)[:11]}",    0, 24)   # e.g. "Pos: 200"
    oled.text(f"Stat:{str(status)[:11]}", 0, 34)   # e.g. "Stat:Moving"
    oled.text(f"Err: {err_label[:11]}",   0, 44)   # e.g. "Err: OK"
    oled.text("Hold/Press>Drive",   0, 56)   # instruction
    oled.show()

# ===========================================================================
# BUTTON TEST SCREEN
# ===========================================================================

def draw_button_test(center=""):
    """
    Button test mode screen. Shows "BUTTON TEST" as header.
    center — button name to display in the middle of the screen while held.
    Call with center="" when the button is released (clears the label).
    """
    oled.fill(0)
    _header("BUTTON TEST")
    if center:
        oled.text(center[:16], 0, 32)   # display in the vertical center of the screen
    oled.text("HMI - J.Alger :)",0, 56)         # copyright at bottom
    oled.show()

# ===========================================================================
# LEGACY / ORIGINAL FUNCTIONS
# Kept from the original my_oled.py for backwards compatibility.
# ===========================================================================

def print_text(msg, x=0, y=0):
    """Clear the screen and print a single message at (x, y)."""
    oled.fill(0)
    oled.text(msg, x, y)
    oled.show()

def plot_line(*args, **kwargs):
    """Placeholder — not yet implemented."""
    print('plot_line: not yet implemented')

def triforce():
    """
    Draw the triforce using three filled triangles.
    fill_triangle(x0,y0, x1,y1, x2,y2, color) draws a solid triangle
    defined by three corner points. color=1 means white (pixel on).
    """
    oled.fill(0)
    # Top triangle (pointing up)
    graphics.fill_triangle(64, 16, 48, 32, 80, 32, 1)
    # Bottom-left triangle
    graphics.fill_triangle(48, 32, 32, 48, 64, 48, 1)
    # Bottom-right triangle
    graphics.fill_triangle(80, 32, 64, 48, 96, 48, 1)
    oled.show()