# boot.py
# just here for standard practice, no code