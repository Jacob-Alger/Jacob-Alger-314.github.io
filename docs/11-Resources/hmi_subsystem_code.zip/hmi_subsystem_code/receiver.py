# receiver.py
# Jacob Alger - Team 202 - EGR 314
#
# Incoming packet buffering, parsing, routing, and message handling.
#
# ── FULL API COVERAGE (received messages) ────────────────────────────────────
#   AV:F:##;          Accelerometer Value        from p (Tyler)
#   AA:IL:##;         Arm Position Acknowledge   from a (Caleb)
#   AS:S:...;         Arm Status                 from a (Caleb)
#   AE:I:#;           Arm Error                  from a (Caleb)
#   TV:F:##;TT:S:C/F; Temperature Value + Unit   from t (Isaiah)
#   HV:F:##;          Humidity Value             from t (Isaiah)
#   MD:S:T/F;         Metal Detector Value       from m (Aaron)
#   ST:S:Start;       Start broadcast echo       from any (broadcast re-send)
# ─────────────────────────────────────────────────────────────────────────────

import time
from protocol import (parse_packet, parse_fields, DTYPE_NAMES,
                      ID_HMI, ID_BCAST)
from hardware import (led_blue, BLUE_BRIGHTNESS)   # blue LED for receive acknowledgement

# ===========================================================================
# LAST RECEIVED READINGS
# This dictionary is the shared memory between the receiver and the display.
# When a message arrives, its handler stores the value here.
# my_oled.draw_sensor_sub() reads from here when refreshing the screen.
# main.py imports this dict directly: `from receiver import last_readings`
# ===========================================================================

last_readings = {
    'accel'      : None,   # Most recent accelerometer reading, e.g. "42.5"
    'temp'       : None,   # Most recent temperature reading,   e.g. "76.5"
    'temp_unit'  : None,   # Current temp unit reported by sensor, "C" or "F"
    'humid'      : None,   # Most recent humidity reading,      e.g. "31.2"
    'metal'      : None,   # Most recent metal detector reading, "T" or "F"
    'arm_pos'    : None,   # Most recent arm position,          e.g. "90"
    'arm_status' : None,   # Most recent arm status,  e.g. "Moving" or "Idle"
    'arm_error'  : None,   # Most recent arm error code,        e.g. "1"
}

# ===========================================================================
# FIELD PRETTY-PRINTER
# Shared by all message handlers for consistent console output.
# ===========================================================================

def _describe_fields(fields):
    """Print each parsed field to the console in a readable format."""
    for (name, dtype, value) in fields:
        # Look up the long name for the type code, fall back to the code itself
        type_label = DTYPE_NAMES.get(dtype, dtype)
        print(f"    Field : {name}  Type: {type_label}  Value: {value}")

# ===========================================================================
# MESSAGE HANDLERS
# One function per incoming message type.
# Each receives the parsed fields list: [(name, type, value), ...]
# Each stores the relevant value into last_readings for the display.
#
# ── HOW TO ADD A NEW MESSAGE TYPE ────────────────────────────────────────────
#   1. Write a handle_XX() function here following the same pattern.
#   2. Add it to MESSAGE_HANDLERS below with the matching name key.
#   That's all — no other file needs to change.
# ─────────────────────────────────────────────────────────────────────────────
# ===========================================================================

def handle_AV(fields):
    """
    Accelerometer Value — received from Pressure/Accel subsystem (p / Tyler)
    Full example: AZphAV:F:42.5;YB
    Stores the float value string into last_readings['accel'].
    """
    print("  >> Accelerometer Value received")
    _describe_fields(fields)
    for (name, dtype, value) in fields:
        if name == 'AV:':                      # find the accelerometer field
            last_readings['accel'] = value     # store it for the OLED display


def handle_AA(fields):
    """
    Arm Position Acknowledge — received from Front Arm subsystem (a / Caleb)
    Full example: AZahAA:IL:90;YB
    Stores the int16 position string into last_readings['arm_pos'].
    """
    print("  >> Arm Position Acknowledge received")
    _describe_fields(fields)
    for (name, dtype, value) in fields:
        if name == 'AA:':
            last_readings['arm_pos'] = value


def handle_AS(fields):
    """
    Arm Status — received from Front Arm subsystem (a / Caleb)
    Full example: AZahAS:S:Moving;YB
    Possible values: Idle, Moving, Done, Halted
    Stores the status string into last_readings['arm_status'].
    """
    print("  >> Arm Status received")
    _describe_fields(fields)
    for (name, dtype, value) in fields:
        if name == 'AS:':
            last_readings['arm_status'] = value


def handle_AE(fields):
    """
    Arm Error — received from Front Arm subsystem (a / Caleb)
    Full example: AZahAE:I:1;YB
    Error codes 0-3 (0 = no error).
    Stores the error code string into last_readings['arm_error'].
    """
    print("  >> Arm Error received")
    _describe_fields(fields)
    for (name, dtype, value) in fields:
        if name == 'AE:':
            last_readings['arm_error'] = value


def handle_TV(fields):
    """
    Temperature Value + Unit — received from Temp/Humidity subsystem (t / Isaiah)
    Full example: AZthTV:F:76.5;TT:S:F;YB
    This message contains TWO fields back-to-back:
        TV:F:76.5;   — the temperature reading as a float
        TT:S:F;      — the current unit (C or F) as a string
    Both are stored separately in last_readings.
    """
    print("  >> Temperature Value + Unit received")
    _describe_fields(fields)
    for (name, dtype, value) in fields:
        if name == 'TV:':                          # temperature reading field
            last_readings['temp'] = value
        elif name == 'TT:':                        # temperature unit field
            last_readings['temp_unit'] = value     # will be "C" or "F"


def handle_HV(fields):
    """
    Humidity Value — received from Temp/Humidity subsystem (t / Isaiah)
    Full example: AZthHV:F:31.2;YB
    Stores the float value string into last_readings['humid'].
    """
    print("  >> Humidity Value received")
    _describe_fields(fields)
    for (name, dtype, value) in fields:
        if name == 'HV:':
            last_readings['humid'] = value


def handle_MD(fields):
    """
    Metal Detector Value — received from Metal Detector subsystem (m / Aaron)
    Full example: AZmhMD:S:T;YB
    Value is "T" (metal detected) or "F" (no metal).
    Stores the string into last_readings['metal'].
    """
    print("  >> Metal Detector Value received")
    _describe_fields(fields)
    for (name, dtype, value) in fields:
        if name == 'MD:':
            last_readings['metal'] = value


def handle_ST(fields):
    """
    Start Broadcast echo — received when a teammate re-broadcasts the start message.
    Full example: AZtXST:S:Start;YB  (source = teammate, dest = broadcast X)
    This is how we confirm the network is alive after pressing SEL on the start screen.
    No value is stored — main.py watches process_incoming()'s return value for 'ST'.
    """
    print("  >> START broadcast echo received — network is alive!")
    _describe_fields(fields)

# ===========================================================================
# DISPATCH TABLE
# Maps the first field name of a message to its handler function.
# _dispatch() looks up the handler here and calls it automatically.
# Adding a new message type only requires adding a line to this dict
# (and writing the handler function above).
# ===========================================================================

MESSAGE_HANDLERS = {
    'AV:' : handle_AV,    # Accelerometer Value        (from p)
    'AA:' : handle_AA,    # Arm Position Acknowledge   (from a)
    'AS:' : handle_AS,    # Arm Status                 (from a)
    'AE:' : handle_AE,    # Arm Error                  (from a)
    'TV:' : handle_TV,    # Temperature Value + Unit   (from t)
    'HV:' : handle_HV,    # Humidity Value             (from t)
    'MD:' : handle_MD,    # Metal Detector Value       (from m)
    'ST:' : handle_ST,    # Start broadcast echo       (broadcast)
}

# ===========================================================================
# LED ACKNOWLEDGEMENT
# Pulses the blue LED briefly whenever a packet addressed to us is handled.
# ===========================================================================

def _ack_leds():
    """Brief blue LED flash — visual confirmation a packet was received."""
    led_blue.duty_u16(BLUE_BRIGHTNESS)       # LED on
    time.sleep_ms(50)        # hold for 50 ms (long enough to see)
    led_blue.duty_u16(0)        # LED off

# ===========================================================================
# DISPATCHER
# Called internally by route_packet() with the raw message bytes.
# Parses the fields, finds the right handler, and calls it.
# ===========================================================================

def _dispatch(message_bytes):
    """
    Parse the message body and call the matching handler.
    The handler is looked up by the name of the first field (e.g. 'AV:').
    """
    # Parse the raw bytes into a list of (name, type, value) tuples
    fields = parse_fields(message_bytes)

    if not fields:
        print("  [WARN] Could not parse any fields from message body.")
        return

    # The first field's name determines which handler to call.
    # e.g. for "AV:F:80.0;" the first field name is "AV:"
    msg_name = fields[0][0]

    # Look up the handler in the dispatch table
    handler = MESSAGE_HANDLERS.get(msg_name)

    if handler:
        handler(fields)   # call it with the full fields list
    else:
        print(f"  [WARN] No handler registered for message type: '{msg_name}'")

# ===========================================================================
# ROUTER
# Decides what to do with a validated packet based on its destination ID.
# ===========================================================================

def route_packet(pkt):
    """
    Route a validated packet dict (from parse_packet) to the correct action.

    Routing rules:
      src == ID_HMI  → discard  (our own message looped back to us)
      dest == ID_HMI → handle and dispose (it's for us; don't pass it on)
      dest == ID_BCAST → handle locally AND forward to next node
      anything else  → pass it on without touching it

    Returns a short string for OLED display if we handled it, else None.
    """
    src  = pkt["src_id"]    # integer ID of who sent this
    dest = pkt["dest_id"]   # integer ID of who should receive it
    msg  = pkt["message"]   # raw bytes of the message body

    # Print routing info to console for debugging
    print(f"  Src    : '{chr(src)}' (0x{src:02X})")
    print(f"  Dest   : '{chr(dest)}' (0x{dest:02X})")
    print(f"  Message: {msg}")

    # ── Rule 1: Loopback — discard ──────────────────────────────────────────
    # If we see our own ID as the source, the packet went all the way around
    # the daisy chain without being consumed. Silently discard it.
    if src == ID_HMI:
        print("  [DISCARD] This packet originated from us and looped back.")
        return None

    # ── Rule 2: Addressed to us — handle and dispose ────────────────────────
    # If dest matches our ID, this message is meant for HMI. Handle it and
    # do NOT forward it — consuming it here removes it from the network.
    if dest == ID_HMI:
        print("  [FOR ME] Dispatching to handler...")
        _dispatch(msg)      # find the right handler and call it
        _ack_leds()         # pulse blue LED as visual acknowledgement

        # Build a short string to show on the OLED (max ~16 chars readable)
        try:
            text = msg.decode('utf-8', 'replace')
            return f"RX {chr(src)}: {text[:12]}"   # e.g. "RX p: AV:F:42.5"
        except Exception:
            return f"RX {chr(src)}"

    # ── Rule 3: Broadcast — handle locally AND forward ──────────────────────
    # If dest is the broadcast address (X), everyone should act on it.
    # We handle it (e.g. the start echo) but also forward it downstream.
    if dest == ID_BCAST:
        print("  [BROADCAST] Handling locally and passing on...")
        _dispatch(msg)
        _ack_leds()
        # TODO: forward the raw packet bytes to the next node via UART TX
        try:
            text = msg.decode('utf-8', 'replace')
            return f"BC: {text[:13]}"   # e.g. "BC: ST:S:Start"
        except Exception:
            return "BC received"

    # ── Rule 4: Not for us — pass on ────────────────────────────────────────
    # The packet is addressed to someone else on the network.
    # Forward it without modifying it.
    print(f"  [PASS ON] Not for us — forwarding to '{chr(dest)}'")
    # TODO: forward the raw packet bytes to the next node via UART TX
    return None   # we didn't handle it, so no OLED update

# ===========================================================================
# RX BUFFER
# Bytes arrive one at a time from uart.read(1). We accumulate them here
# until we see a '\n' (newline), which signals end-of-packet.
# This is a module-level variable so it persists between calls to
# process_incoming() — each call picks up where the last one left off.
# ===========================================================================

_rx_buffer = b""   # starts empty; grows with each incoming byte

# ===========================================================================
# PROCESS INCOMING
# Called by main.py every loop iteration. Reads all available UART bytes,
# assembles complete packets, and routes them.
# ===========================================================================

def process_incoming(uart):
    """
    Non-blocking UART receive loop. Reads whatever bytes are available
    right now (does not wait for more), accumulates them in _rx_buffer,
    and processes a complete packet whenever '\n' is seen.

    Returns a short OLED-friendly string if a packet was handled this call,
    or None if no complete packet arrived (or it wasn't for us).

    Called from the main loop every 10 ms, so at 9600 baud (960 bytes/sec)
    we can comfortably keep up with the incoming data rate.
    """
    global _rx_buffer   # we need to modify the module-level buffer
    oled_update = None  # will be set if a packet produces a display update

    # uart.any() returns the number of bytes waiting in the receive FIFO.
    # We loop until there are none left (drain everything available).
    while uart.any():
        c = uart.read(1)   # read exactly one byte; returns a bytes object

        if c == b'\n':
            # Newline = end of packet. Process whatever we've accumulated.
            # .strip() removes any trailing \r or whitespace.
            line = _rx_buffer.strip()
            _rx_buffer = b""    # reset buffer immediately for next packet

            if line:   # ignore empty lines (e.g. a bare \r\n)
                print(f"\n--- Packet received ({len(line)} bytes) ---")
                print(f"Raw: {line}")

                # Try to parse the raw bytes as a valid packet
                pkt = parse_packet(line)

                if pkt:
                    # Valid packet — route it and get back any display string
                    result = route_packet(pkt)
                    if result:
                        oled_update = result   # pass back to main.py for OLED

                # If parse_packet returned None, the packet was malformed
                # and parse_packet already printed the reason. We just skip it.

        else:
            # Not a newline — accumulate this byte into the buffer.
            _rx_buffer += c

    return oled_update   # None if nothing display-worthy happened this call
