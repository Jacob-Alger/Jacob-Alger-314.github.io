# protocol.py
# Jacob Alger - Team 202 - EGR 314
#
# Packet building, parsing, field parsing, and protocol constants.
# This file has NO hardware dependencies — it can be tested on a laptop
# with plain Python if needed.
#
# ── PACKET STRUCTURE (64 bytes total) ───────────────────────────────────────
#   Byte 0-1 : Prefix  (0x41 0x5A = "AZ")
#   Byte 2   : Source ID  (single ASCII char, e.g. 'h' for HMI)
#   Byte 3   : Dest ID    (single ASCII char, e.g. 'w' for Wheels)
#   Byte 4-61: Message data (variable length, max 58 bytes)
#   Byte 62-63: Suffix (0x59 0x42 = "YB")
#
# ── MESSAGE DATA FORMAT ──────────────────────────────────────────────────────
#   Each field inside the message follows the pattern:
#     NAME:TYPE:VALUE;
#   e.g.  AV:F:80.0;   means field "AV:", type Float, value "80.0"
#   Multiple fields can appear back-to-back in one message:
#     TV:F:76.5;TT:S:F;
# ─────────────────────────────────────────────────────────────────────────────

# ===========================================================================
# PROTOCOL CONSTANTS
# ===========================================================================

# These two byte sequences mark the start and end of every packet.
# b'\x41\x5A' is the ASCII bytes for "AZ"
# b'\x59\x42' is the ASCII bytes for "YB"
PREFIX  = b'\x41\x5A'   # "AZ" — every valid packet starts with this
SUFFIX  = b'\x59\x42'   # "YB" — every valid packet ends with this

# Maximum number of bytes allowed in the message data section.
# The full packet is 64 bytes: 2 prefix + 1 src + 1 dest + 58 msg + 2 suffix
MAX_MSG = 58

# ===========================================================================
# SUBSYSTEM IDs
# Each board on the team has a unique single-character ASCII ID.
# ord() converts the character to its integer byte value.
# e.g. ord('h') = 104 = 0x68
# ===========================================================================

ID_HMI   = ord('h')   # Human-Machine Interface — this board (Jacob)
ID_COMM  = ord('c')   # Communication subsystem (Cris)
ID_WHEEL = ord('w')   # Wheel drive subsystem (Asadbek)
ID_ACCEL = ord('p')   # Pressure / Accelerometer subsystem (Tyler)
ID_ARM   = ord('a')   # Front Arm subsystem (Caleb)
ID_METAL = ord('m')   # Metal Detector subsystem (Aaron)
ID_TEMP  = ord('t')   # Temperature / Humidity subsystem (Isaiah)
ID_BCAST = ord('X')   # Broadcast address — all subsystems receive this

# ===========================================================================
# DATA TYPE LABELS
# Used only for human-readable console output when printing received fields.
# The actual type prefix in a message is the short form (e.g. "F:").
# ===========================================================================

DTYPE_NAMES = {
    'S:'  : 'String',    # ASCII character array
    'I:'  : 'Int8',      # 8-bit integer
    'IL:' : 'Int16',     # 16-bit integer
    'F:'  : 'Float32',   # 32-bit float
}

# ===========================================================================
# FIELD PARSER
# ===========================================================================

def parse_fields(message_bytes):
    """
    Break a raw message body into a list of (name, type, value) tuples.

    Each field in the message follows the pattern:  NAME:TYPE:VALUE;
    For example:
        b'AV:F:80.0;'  ->  [('AV:', 'F:', '80.0')]
        b'TV:F:76.5;TT:S:F;'  ->  [('TV:', 'F:', '76.5'), ('TT:', 'S:', 'F')]

    The semicolon ';' acts as a field terminator.
    The colon ':' separates name, type, and value within each field.

    Returns a list of tuples. Returns an empty list if nothing can be parsed.
    """
    fields = []

    # Try to decode the raw bytes into a Python string using UTF-8.
    # 'replace' means any un-decodable bytes become '?' instead of crashing.
    try:
        text = message_bytes.decode('utf-8', 'replace')
    except Exception:
        return fields   # return empty list if decoding fails entirely

    # Split the whole message on ';' to isolate each field segment.
    # e.g. "AV:F:80.0;MD:S:T;" -> ["AV:F:80.0", "MD:S:T", ""]
    for seg in text.split(';'):
        seg = seg.strip()   # remove any surrounding whitespace or \r\n

        if not seg:
            continue   # skip empty segments (e.g. the part after the last ';')

        # Split the segment on ':' to separate name, type, and value.
        # e.g. "AV:F:80.0" -> ["AV", "F", "80.0"]
        parts = seg.split(':')

        if len(parts) < 3:
            # A valid field needs at least 3 parts: name, type, value.
            print(f"    [WARN] Unparseable field segment: '{seg}'")
            continue

        name  = parts[0] + ':'          # e.g. "AV:" — re-add the colon
        dtype = parts[1] + ':'          # e.g. "F:"  — re-add the colon
        # Re-join any remaining parts in case the value itself contained ':'
        value = ':'.join(parts[2:])     # e.g. "80.0"

        fields.append((name, dtype, value))   # add the tuple to our list

    return fields

# ===========================================================================
# PACKET BUILDER
# ===========================================================================

def build_packet(src_id, dest_id, message_str):
    """
    Assemble and validate a complete outgoing packet.

    Structure assembled:
        PREFIX (2B) + SRC (1B) + DEST (1B) + MESSAGE (<=58B) + SUFFIX (2B)

    Safety checks performed:
        1. Message can be encoded to UTF-8 bytes
        2. Message length does not exceed MAX_MSG (58 bytes)
        3. Message body does not contain the PREFIX or SUFFIX byte sequences
           (which would confuse any receiver trying to find packet boundaries)

    Returns the complete packet as a bytes object on success.
    Returns None on failure (error is printed to console).
    """

    # Convert the message string to bytes so we can check its length
    # and scan it for forbidden sequences.
    try:
        msg_bytes = message_str.encode('utf-8')
    except Exception as e:
        print(f"  [ERROR] Message encoding failed: {e}")
        return None

    # Reject messages that are too long for the packet format.
    if len(msg_bytes) > MAX_MSG:
        print(f"  [ERROR] Message too long ({len(msg_bytes)} bytes, max {MAX_MSG})")
        return None

    # Reject messages whose bytes accidentally contain the prefix or suffix.
    # If "AZ" or "YB" appeared inside the data, a receiver would think the
    # packet ended early or a new one started mid-message.
    if PREFIX in msg_bytes or SUFFIX in msg_bytes:
        print("  [ERROR] Message body contains prefix or suffix bytes — rejected.")
        return None

    # Assemble the packet by concatenating all sections.
    # bytes([src_id, dest_id]) creates a 2-byte sequence from the two integers.
    return PREFIX + bytes([src_id, dest_id]) + msg_bytes + SUFFIX

# ===========================================================================
# PACKET PARSER
# ===========================================================================

def parse_packet(raw):
    """
    Validate and decompose a raw incoming byte string into its packet fields.

    Minimum valid packet length:
        2 (prefix) + 1 (src) + 1 (dest) + 1 (min message) + 2 (suffix) = 7 bytes

    Returns a dict with keys: prefix, src_id, dest_id, message, suffix
    Returns None if the packet fails any validation check.
    """

    # If we somehow received a Python string instead of bytes, convert it.
    if isinstance(raw, str):
        try:
            raw = raw.encode('utf-8')
        except Exception:
            return None

    # Reject anything too short to be a valid packet.
    if len(raw) < 7:
        print(f"  [INVALID] Packet too short ({len(raw)} bytes, minimum 7)")
        return None

    # Slice the raw bytes into their named sections.
    # Python slicing: raw[0:2] means bytes at index 0 and 1 (not 2).
    prefix  = raw[0:2]    # first 2 bytes
    src_id  = raw[2]      # single byte — Python gives us an int from indexing bytes
    dest_id = raw[3]      # single byte
    message = raw[4:-2]   # everything between header and suffix
    suffix  = raw[-2:]    # last 2 bytes

    # Validate prefix — must exactly match our expected "AZ" bytes.
    if prefix != PREFIX:
        print(f"  [INVALID] Bad prefix: {prefix}")
        return None

    # Validate suffix — must exactly match our expected "YB" bytes.
    if suffix != SUFFIX:
        print(f"  [INVALID] Bad suffix: {suffix}")
        return None

    # Return all fields as a dict for easy access by name in the caller.
    return {
        "prefix"  : prefix,
        "src_id"  : src_id,    # integer byte value, e.g. 104 for 'h'
        "dest_id" : dest_id,   # integer byte value
        "message" : message,   # raw bytes of message body
        "suffix"  : suffix,
    }
