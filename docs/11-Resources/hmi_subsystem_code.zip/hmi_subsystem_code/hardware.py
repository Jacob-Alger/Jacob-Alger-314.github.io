# hardware.py
# Jacob Alger - Team 202 - EGR 314
#
# All hardware initialization for the HMI ESP32-S3.
# ── BUTTON DESIGN ────────────────────────────────────────────────────────────
# Buttons use IRQ (interrupt) driven detection rather than polling.
#
# The IRQ handler only sets a flag — it does NOT call send_packet() or
# update the display. Hardware interrupts must be very short; doing complex
# work inside them can crash MicroPython. main.py reads the flag each loop.
# ─────────────────────────────────────────────────────────────────────────────

from machine import UART, Pin, Timer, SoftI2C   # MicroPython hardware classes
import ssd1306   # OLED display driver
import gfx       # Graphics helper for shapes (triangles etc.)
import time      # For ticks_ms() used in debounce

# ===========================================================================
# UART  (Universal Asynchronous Receiver-Transmitter)
# This is the serial bus connecting all boards in the daisy chain.
# ===========================================================================

uart = UART(2, 9600, tx=17, rx=18)

# .init() sets the frame format: 8 data bits, no parity, 1 stop bit.
uart.init(9600, bits=8, parity=None, stop=1)

# ===========================================================================
# LEDs
# ===========================================================================

led_red    = Pin(12, Pin.OUT)   # Red LED — heartbeat, blinks once per second

# Blue LED on IO10 — PWM driven for brightness control.
# freq=1000 Hz is fast enough that the eye sees steady light, not flicker.
# duty_u16() takes a value from 0 (off) to 65535 (full brightness).
# Current setting is 20% brightness — adjust BLUE_BRIGHTNESS to taste.
from machine import PWM
BLUE_BRIGHTNESS = 6553   # 20% of 65535 — adjust this value:
                           #   6553  = 10%  (very dim)
                           #   13107 = 20%  (subtle)
                           #   32767 = 50%  (half)
                           #   65535 = 100% (full, original behavior)
led_blue = PWM(Pin(10), freq=1000, duty_u16=0)   # start off

wifi_ready = Pin(9,  Pin.IN, Pin.PULL_DOWN)    # Input from comm subsystem — HIGH when MQTT handshake complete

# ===========================================================================
# OLED DISPLAY
# The display uses I2C to connect to the ESP32-S3
# ===========================================================================

i2c      = SoftI2C(scl=Pin(13), sda=Pin(14))
oled     = ssd1306.SSD1306_I2C(128, 64, i2c)
graphics = gfx.GFX(128, 64, oled.pixel)

# ===========================================================================
# BUTTONS
# All buttons are wired with external pull-up resistors
# ===========================================================================

# List of all button GPIO pin numbers on this board.
BUTTON_PINS = [4, 5, 6, 7, 8, 11, 15, 16]

# Dictionary mapping pin numbers to human-readable names.
# Used in button test mode and console debug output.
BUTTON_NAMES = {
    4 : "UP",
    5 : "RIGHT",
    6 : "DOWN",
    7 : "LEFT",
    8 : "MENU",
    11: "DEBUG",
    15: "SELECT",
    16: "BACK",
}

# ===========================================================================
# SHARED IRQ STATE
# These three variables are written by the IRQ handler and read by main.py.
# Because they cross the boundary between interrupt context and normal code,
# they are module-level globals (the simplest safe approach in MicroPython).
# ===========================================================================

button_flag  = False   # Set to True by IRQ when a new press is detected.
                       # main.py clears this back to False after handling it.

last_button  = None    # Stores the pin number of the most recent button press.
                       # Only valid to read when button_flag is True.

pressed_lock = {}      # Dict of {pin_num: bool}. True means this button's
                       # IRQ is "locked out" until the button is physically
                       # released. Prevents a single press from firing twice.

DEBOUNCE_MS  = 200     # Minimum milliseconds between accepted button presses.
                       # Mechanical buttons "bounce" (rapidly open/close) for
                       # a few ms when pressed; this gap filters that out.

_last_irq_ms = 0       # Timestamp of the last accepted IRQ event.
                       # Used for global debounce across all buttons.

# ===========================================================================
# IRQ HANDLER FACTORY
# We need one IRQ handler per button, each knowing its own pin number.
# EX: _make_handler(4) returns a function that always knows it's for pin 4.
# ===========================================================================

def _make_handler(pin_num):
    """
    Returns a closure (a function that remembers pin_num) to use as
    the IRQ callback for the button on that pin.
    """
    def handler(pin):
        # 'global' tells Python we want to modify the module-level variables,
        # not create new local ones inside this function.
        global button_flag, last_button, _last_irq_ms

        now = time.ticks_ms()   # current time in milliseconds

        # If this button is locked (already pressed and not yet released),
        # ignore this IRQ — it's either a bounce or a held-button repeat.
        if pressed_lock[pin_num]:
            return

        # Global debounce: if any button fired very recently, ignore this one.
        # ticks_diff() is used instead of subtraction to handle the ms counter
        # wrapping around at its maximum value (safe subtraction for timers).
        if time.ticks_diff(now, _last_irq_ms) > DEBOUNCE_MS:
            pressed_lock[pin_num] = True   # lock this button until release
            last_button  = pin_num         # record which button was pressed
            button_flag  = True            # signal main loop to handle it
            _last_irq_ms = now             # update debounce timestamp

    return handler   # return the inner function with pin_num "baked in"

# ===========================================================================
# BUTTON INITIALIZATION LOOP
# Create a Pin object and attach the IRQ handler for each button.
# ===========================================================================

buttons = {}   # Will hold {pin_num: Pin object} for all buttons

for _p in BUTTON_PINS:
    _btn = Pin(_p, Pin.IN)          # configure as input (no internal pull-up)
    buttons[_p] = _btn              # store Pin object for later use (e.g. .value())
    pressed_lock[_p] = False        # initially unlocked
    # Attach the IRQ: fire handler on FALLING edge (HIGH->LOW = button press).
    _btn.irq(trigger=Pin.IRQ_FALLING, handler=_make_handler(_p))

# ===========================================================================
# HEARTBEAT TIMER
# A hardware timer fires a callback every 1000 ms to toggle the red LED.
# This runs completely independently of the main loop — even if main.py is
# busy, the LED will keep blinking, showing the board is alive.
# ===========================================================================

def _heartbeat_cb(t):
    # XOR the current LED state with 1 to toggle it:
    led_red.value(led_red.value() ^ 1)

heartbeat_timer = Timer(0)   # Timer(0) uses the ESP32's first hardware timer
heartbeat_timer.init(
    period   = 1000,           # fire every 1000 milliseconds
    mode     = Timer.PERIODIC, # keep repeating (not just once)
    callback = _heartbeat_cb   # function to call each time it fires
)
