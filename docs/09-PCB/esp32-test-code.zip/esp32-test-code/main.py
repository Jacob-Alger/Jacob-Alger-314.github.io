# Jacob Alger - Team 202 - EGR 314
# Code generated with assistance from Claude
# This code tests the buttons and the OLED screen by running a button test, 
# and shows the functionality of the menu button to switch states of the OLED screen

from machine import Pin
import my_oled
import time

# ===== LED SETUP =====
debug_led = Pin(12, Pin.OUT) # Red LED
BT_led = Pin(10, Pin.OUT)    # Blue LED

# ===== GLOBAL STATE =====
# Stores the last button that triggered an interrupt
last_button = None

# Flag to tell main loop a button event happened
button_flag = False

# Used for debounce timing
last_time = 0
DEBOUNCE_MS = 200

# Tracks if a button is currently "locked" (prevents repeat triggers while held)
pressed_lock = {}

# Variable for which button is being pressed
active_button = None

# ===== HEARTBEAT TIMER =====
last_heartbeat = 0
HEARTBEAT_INTERVAL = 1000  # milliseconds

# ===== MODE STATE =====
MODE_BUTTON_TEST = 0
MODE_TRIFORCE = 1
mode = MODE_BUTTON_TEST

# Stores what we are currently displaying in the middle of the screen
current_display = ""

# ===== INTERRUPT HANDLER =====
# This function is called when a button is pressed
def make_handler(pin_num):
    def handler(pin):
        global last_button, button_flag, last_time

        now = time.ticks_ms()

        # Ignore if button is already being held
        if pressed_lock[pin_num]:
            return

        # Simple debounce check
        if time.ticks_diff(now, last_time) > DEBOUNCE_MS:
            pressed_lock[pin_num] = True   # lock this button
            last_button = pin_num          # store which button
            button_flag = True             # notify main loop
            last_time = now

    return handler

# ===== SETUP BUTTONS =====
pins = [4, 5, 6, 7, 8, 11, 15, 16]
buttons = {}

for p in pins:
    btn = Pin(p, Pin.IN)
    buttons[p] = btn
    pressed_lock[p] = False
    # Trigger interrupt when button is pressed (HIGH → LOW)
    btn.irq(trigger=Pin.IRQ_FALLING, handler=make_handler(p))

# ===== INITIAL DISPLAY =====
my_oled.print_text("OLED BUTTON TEST", 0, 0)

# ===== MAIN LOOP =====
while True:
    now = time.ticks_ms()

    # ===== HEARTBEAT LED =====
    # Toggle LED every second (non-blocking)
    if time.ticks_diff(now, last_heartbeat) > HEARTBEAT_INTERVAL:
        debug_led.value(not debug_led.value())
        last_heartbeat = now

    # ===== BUTTON RELEASE CHECK =====
    # This detects when a button is released
    for p in pins:
        if buttons[p].value() == 1:  # released
            pressed_lock[p] = False

            # ONLY clear if THIS was the active button
            if mode == MODE_BUTTON_TEST and p == active_button:
                current_display = ""
                active_button = None

                my_oled.oled.fill(0)
                my_oled.oled.text("OLED BUTTON TEST", 0, 0)
                my_oled.oled.show()

    # ===== BUTTON PRESS EVENT =====
    if button_flag:
        button_flag = False
        p = last_button

        print(f"GPIO {p} PRESSED")
        active_button = p

        # ===== MENU BUTTON: TOGGLE MODE =====
        if p == 8:  # MENU button
            if mode == MODE_BUTTON_TEST:
                mode = MODE_TRIFORCE
                my_oled.triforce()
                BT_led.value(1)
            else:
                mode = MODE_BUTTON_TEST
                current_display = ""
                my_oled.print_text("OLED BUTTON TEST", 0, 0)
                BT_led.value(0)


        # ===== BUTTON TEST MODE =====
        elif mode == MODE_BUTTON_TEST:

            # Determine which button is pressed
            if p == 4:
                current_display = "UP"
            if p == 5:
                current_display = "RIGHT"
            if p == 6:
                current_display = "DOWN"
            if p == 7:
                current_display = "LEFT"
            if p == 11:
                current_display = "DEBUG"
            if p == 15:
                current_display = "SELECT"
            if p == 16:
                current_display = "BACK"

            # Draw screen (top + middle)
            my_oled.oled.fill(0)
            my_oled.oled.text("OLED BUTTON TEST", 0, 0)
            my_oled.oled.text(current_display, 0, 32)
            my_oled.oled.show()

    # Small delay to reduce CPU usage (still non-blocking)
    time.sleep(0.01)